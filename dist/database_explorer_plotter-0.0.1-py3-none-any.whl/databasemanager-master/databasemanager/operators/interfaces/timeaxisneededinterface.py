#==================================================#
# Authors: Amir H. Ansari <amirans65.ai@gmail.com> #
# License: BSD (3-clause)                          #
#==================================================#

from databasemanager.operators.interfaces.axisneededinteface import AxisNeededInterface

class TimeAxisNeededInterface(AxisNeededInterface):
    pass