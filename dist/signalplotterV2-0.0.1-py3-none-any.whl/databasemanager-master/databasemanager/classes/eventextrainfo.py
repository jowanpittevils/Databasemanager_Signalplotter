#==================================================#
# Authors: Amir H. Ansari <amirans65.ai@gmail.com> #
# License: BSD (3-clause)                          #
#==================================================#

from databasemanager.classes.extrainfo import ExtraInfo
class EventExtraInfo(ExtraInfo):
    pass