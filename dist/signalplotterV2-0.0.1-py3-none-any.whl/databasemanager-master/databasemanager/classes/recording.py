
#==================================================#
# Authors: Amir H. Ansari <amirans65.ai@gmail.com> #
# License: BSD (3-clause)                          #
#==================================================#

from databasemanager.classes.recordingbase import RecordingBase

class Recording(RecordingBase):
    pass