# Database Explorer & Plotter

This is a python package designed to make navigating through biomedical signal databases easier, and to allow the user to plot and explore the signals.
The package requires the databasemanager package (https://gitlab.com/amirans65/databasemanager) to be installed on your machine.


[Github-flavored Markdown]
